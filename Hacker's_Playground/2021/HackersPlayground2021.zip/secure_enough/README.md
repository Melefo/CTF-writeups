# Secure Enough

## Description
I made secure communication algorithm. No one can see my message.

## Flag
- SCTF{B3_CAR3_FULL_W1T4_RAND0M}

## Problem
Reverse engineer the binary and find flag from packets.
- insecure_random : client bianry
- out.pcap : packet file