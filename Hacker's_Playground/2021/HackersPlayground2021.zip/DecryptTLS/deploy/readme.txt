[Info]
 Title: DecryptTLS
 Description: This HTTPS client was modified. It has made a trivial choice for its random. This made all TLS packets transparent.
 Attach: DecryptTLS.pcapng

[Deploy]
 Not necessary.

