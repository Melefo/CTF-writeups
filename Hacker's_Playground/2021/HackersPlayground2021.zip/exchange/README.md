# BT Exchange
## Description (in public)
I made a stablecoin named BT.
So I also open the exchange for BT.
Come here and supply liquidity!

## Flag
 - `SCTF{1t_W4s_n0T_MY_f4U1T}`

## Run
 - `cd prob && sudo docker-compose up`

## Re-run
```
cd prob
sudo docker-compose down
sudo docker volume rm $(sudo docker volume ls -q)
sudo docker-compose up -d
```
