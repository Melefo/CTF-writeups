#!/bin/sh
docker build . -t memory_proxy 
