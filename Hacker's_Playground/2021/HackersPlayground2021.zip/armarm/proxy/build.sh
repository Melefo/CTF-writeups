#!/bin/sh
NAME="armarm_proxy"
docker build --tag $NAME ./
