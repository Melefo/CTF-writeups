#!/bin/sh
NAME="armarm"
docker build --tag $NAME:1.0 ./

