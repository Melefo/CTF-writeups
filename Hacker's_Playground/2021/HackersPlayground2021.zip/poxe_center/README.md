## Prob
 - Poxe Center
 - URL : http://ctf.ssat.site:31888/demo/
 - Sorry, but the server code is not included due to some issues.

## Flag
 - `SCTF{G0tcH4_Gh0sT_c4t_iS_L3G3ND4Ry_P0k3}`

## Run
 - `cd prob && sudo docker-compose up`
