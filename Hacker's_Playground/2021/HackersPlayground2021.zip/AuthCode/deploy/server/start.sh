#!/bin/sh
/etc/init.d/xinetd restart
sleep infinity;

