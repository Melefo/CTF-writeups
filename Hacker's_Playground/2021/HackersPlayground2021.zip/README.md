# Challenges for Hacker's Playground 2021

## including exploits and writeups.



## Notice

> Some reports were written in Korean. This is because the author's native language is Korean, so writing directly in English by the author may be of poorer quality than Google Translate. We ask for the understanding of overseas participants.
